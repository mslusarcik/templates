/*
function loadLanguageJSON(callback) {

  var xobj = new XMLHttpRequest();
  xobj.overrideMimeType("application/json");
  xobj.open('GET', './languages.json', true); // Replace 'my_data' with the path to your file
  xobj.onreadystatechange = function () {
    if (xobj.readyState == 4 && xobj.status == "200") {
      // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
      callback(xobj.responseText);
    }
  };
  xobj.send(null);
}
*/
function leadCollectorCreate() {
  var style = document.createElement('style');
  style.innerHTML =
    '.lc-c-alert {' +
    'padding: 15px;' +
    'border: 1px solid transparent;' +
    'display: none' +
    'text-align: center' +
    '}' +
    '.lc-c-success-alert {' +
    'display: block;' +
    'border-color: #6db131;' +
    'background-color: #e7eee5;' +
    'color: #6db131;' +
    '}' +
    '.lc-c-danger-alert {' +
    'display: block;' +
    'border-color: #e20000;' +
    'background-color: #f1d9de;' +
    'color: #e20000;' +
    '}' +
    '.inputValiMessage {' +
    'display: none;' +
    'color: #e20000;' +
    'position: absolute;' +
    'left: 0;' +
    'bottom: -21px;' +
    'font-size: 14px;' +
    '}' +
    '.inputValiMessage.error {' +
    'display: block;' +
    '}' +
    '#lc-c-input.error {' +
    'border: 1px solid #e20000 !important;' +
    '}' +
    '.pos-relative {' +
    'position: relative;' +
    '}';

  // Get the first script tag
  var ref = document.querySelector('script');

  // Insert our new styles before the first script tag
  ref.parentNode.insertBefore(style, ref);

  var input = document.createElement("input");
  input.setAttribute('type', 'hidden');
  input.setAttribute('name', 'recaptcha_response');
  input.setAttribute('id', 'recaptchaResponse');

  var parent = document.getElementById("leadcollector");
  parent.appendChild(input);

  var inputTel = document.getElementById("lc-c-input");
  var closestElement = inputTel.closest("div");
  closestElement.classList.add('pos-relative');
  inputTel.setAttribute('type', 'tel');

  var inputValiMessage = document.createElement("div")
  inputValiMessage.setAttribute("id", "lc-c-vali-message")
  inputValiMessage.setAttribute("class", "inputValiMessage")

  var formMessage = document.createElement("div")
  formMessage.setAttribute("id", "leadcollector-alert")
  formMessage.setAttribute("class", "lc-c-alert")

  parent.appendChild(formMessage);
  closestElement.appendChild(inputValiMessage);
}

function loadRecaptcha() {
  var recaptchaToken = document.getElementById("leadcollector").getAttribute("data-recaptcha-token");

  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://www.google.com/recaptcha/api.js?render=' + recaptchaToken + '';
  document.body.appendChild(script);
}

function submitUserForm(e) {
  e.preventDefault();

  var inputVali = document.forms["leadcollector"]["lc-c-input"].value;
  if (inputVali == "") {
    var elementInput = document.getElementById("lc-c-input");
    var element = document.getElementById("lc-c-vali-message");
    element.classList.add('error');
    elementInput.classList.add('error');

    element.innerHTML = "Toto pole je povinné";
    
    /*
        loadLanguageJSON(function (response) {
          // Parse JSON string into object
          var actual_JSON = JSON.parse(response);

          var lang = sessionStorage.getItem('lang') || navigator.language.slice(0, 2);
          if (lang == "cz") {
            var inputMessage = actual_JSON.cz.inputErrorMessage
          } else {
            var inputMessage = actual_JSON.en.inputErrorMessage
          }

          element.innerHTML = inputMessage
        });
        */

    return false;
  } else {

    var recaptchaToken = document.getElementById("leadcollector").getAttribute("data-recaptcha-token");

    grecaptcha.ready(function () {
      grecaptcha.execute(recaptchaToken, {
        action: 'contact'
      }).then(function (token) {
        var recaptchaResponse = document.getElementById("recaptchaResponse");
        recaptchaResponse.value = token;
      });
    });

    var restApiKey = document.getElementById("leadcollector").getAttribute("data-api-key");
    var leadTemplateNameRequest = document.getElementById("leadcollector").getAttribute("data-leadTemplateNameRequest");
    var leadType = document.getElementById("leadcollector").getAttribute("data-leadType");
    var orderSubType = document.getElementById("leadcollector").getAttribute("data-orderSubType");
    var msisdn = document.getElementById("lc-c-input").value;

    var restApiData = {
      leadTemplateNameRequest: leadTemplateNameRequest,
      leadType: leadType,
      msisdn: msisdn,
      orderSubType: orderSubType
    };

    var json = JSON.stringify(restApiData);

    // Set up our HTTP request
    var xhr = new XMLHttpRequest();

    xhr.open('POST', 'https://lead-api.t2ebiz.cz.tmo/api/createLeadInternal');
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("X-Api-Key", restApiKey);
    // Setup our listener to process completed requests
    xhr.onload = function () {

      // Process our return data
      if (xhr.status >= 200 && xhr.status < 300) {
        var element = document.getElementById("leadcollector-alert");
        element.classList.add('lc-c-success-alert');

        var form = document.getElementById("leadcollector");
        form.classList.add('lc-is-success');

        var elementInput = document.getElementById("lc-c-input");
        var elementValiMessage = document.getElementById("lc-c-vali-message");
        elementValiMessage.classList.remove('error');
        elementInput.classList.remove('error');

        var RestAPI = JSON.parse(this.responseText);
        var labelText = RestAPI.label

        element.innerHTML = labelText

      } else {
        var element = document.getElementById("leadcollector-alert");
        element.classList.add('lc-c-danger-alert');

        var RestAPI = JSON.parse(this.responseText);
        var labelText = RestAPI.label

        element.innerHTML = labelText
      }
    };

    // Create and send a GET request
    xhr.send(json);
  }
}

document.addEventListener('DOMContentLoaded', leadCollectorCreate, false);
document.addEventListener('DOMContentLoaded', loadRecaptcha, false);