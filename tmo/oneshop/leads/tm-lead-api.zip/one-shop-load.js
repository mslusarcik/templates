function loadCollectorJs(){
  var htmlSections = document.querySelectorAll("main .htmlTemplate");
  for (var j = 0; j < htmlSections.length; j++) {
    //Open collapsible
    var element = htmlSections[j].shadowRoot;
    if (element) {
      
      var script = element.createElement('script');
      script.type = 'text/javascript';
      script.src = '';
      element.appendChild(script);
    }
  }
}

var htmlSections = document.querySelectorAll("main .htmlTemplate");
if(htmlSections !== null){
  setTimeout(function(){
    loadCollectorJs();
  }, 1000);
}